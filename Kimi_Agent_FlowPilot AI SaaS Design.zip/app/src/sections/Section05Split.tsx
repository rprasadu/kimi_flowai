import { useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { ArrowRight } from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

export default function Section05Split() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      const leftPanel = section.querySelector('.left-panel')
      const rightPanel = section.querySelector('.right-panel')
      const content = section.querySelector('.right-content')
      const node = section.querySelector('.pulsing-node-wrap')
      if (!leftPanel || !rightPanel || !content || !node) return

      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      })

      // ENTRANCE (0-30%)
      scrollTl.fromTo(leftPanel, { x: '-55vw', opacity: 0 }, { x: 0, opacity: 1, ease: 'power2.out' }, 0)
      scrollTl.fromTo(rightPanel, { x: '55vw', opacity: 0 }, { x: 0, opacity: 1, ease: 'power2.out' }, 0)
      scrollTl.fromTo(Array.from(content.children), { y: '8vh', opacity: 0 }, { y: 0, opacity: 1, ease: 'power2.out', stagger: 0.04 }, 0.10)
      scrollTl.fromTo(node, { scale: 0.2, opacity: 0 }, { scale: 1, opacity: 1, ease: 'back.out(1.4)' }, 0)

      // EXIT (70-100%)
      scrollTl.fromTo(leftPanel, { x: 0, opacity: 1 }, { x: '-18vw', opacity: 0, ease: 'power2.in' }, 0.70)
      scrollTl.fromTo(rightPanel, { x: 0, opacity: 1 }, { x: '18vw', opacity: 0, ease: 'power2.in' }, 0.70)
      scrollTl.fromTo(Array.from(content.children), { y: 0, opacity: 1 }, { y: '-6vh', opacity: 0, ease: 'power2.in', stagger: 0.02 }, 0.72)
      scrollTl.fromTo(node, { scale: 1, opacity: 1 }, { scale: 1.3, opacity: 0, ease: 'power2.in' }, 0.70)

    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={sectionRef} className="pinned-section z-50 flex">
      {/* Left Media Panel */}
      <div className="left-panel absolute left-0 top-0 w-[50vw] h-full z-0">
        <img
          src="/split_editor_ui.jpg"
          alt="Workflow Editor"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#070A12]/80" />
      </div>

      {/* Right Dark Panel */}
      <div className="right-panel absolute right-0 top-0 w-[50vw] h-full bg-[#070A12] z-0" />

      {/* Content */}
      <div className="relative z-10 w-full h-full flex">
        <div className="w-1/2" />
        <div className="w-1/2 flex items-center justify-center">
          <div className="right-content max-w-md px-8">
            <div className="pulsing-node-wrap mb-8">
              <div className="pulsing-node" />
            </div>
            <h2 className="font-heading font-bold text-flow-text mb-6" style={{ fontSize: 'clamp(28px, 3.5vw, 52px)', lineHeight: 1.05 }}>
              Build in minutes.
            </h2>
            <h2 className="font-heading font-bold text-flow-text mb-8" style={{ fontSize: 'clamp(28px, 3.5vw, 52px)', lineHeight: 1.05 }}>
              Run for months.
            </h2>
            <p className="text-flow-text-secondary leading-relaxed mb-8" style={{ fontSize: 'clamp(14px, 1.1vw, 17px)' }}>
              Deploy workflows your team can trust—versioned, monitored, and easy to change when the process evolves.
            </p>
            <button className="btn-secondary gap-2 group">
              See how it works
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
