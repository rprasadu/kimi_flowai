import { useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function Section03Focus() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      const bg = section.querySelector('.bg-image')
      const headline = section.querySelector('.headline')
      const body = section.querySelector('.body-copy')
      const node = section.querySelector('.pulsing-node-wrap')

      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      })

      // ENTRANCE (0-30%)
      scrollTl.fromTo(bg, { scale: 1.06, y: '5vh', opacity: 0.65 }, { scale: 1, y: 0, opacity: 1, ease: 'none' }, 0)
      scrollTl.fromTo(headline, { x: '-12vw', opacity: 0 }, { x: 0, opacity: 1, ease: 'power2.out' }, 0.08)
      scrollTl.fromTo(body, { x: '-8vw', opacity: 0 }, { x: 0, opacity: 1, ease: 'power2.out' }, 0.14)
      scrollTl.fromTo(node, { scale: 0.2, opacity: 0 }, { scale: 1, opacity: 1, ease: 'back.out(1.4)' }, 0)

      // EXIT (70-100%)
      scrollTl.fromTo(bg, { scale: 1, opacity: 1 }, { scale: 1.04, opacity: 0, ease: 'power2.in' }, 0.70)
      scrollTl.fromTo(headline, { x: 0, opacity: 1 }, { x: '-18vw', opacity: 0, ease: 'power2.in' }, 0.70)
      scrollTl.fromTo(body, { opacity: 1 }, { opacity: 0, ease: 'power2.in' }, 0.72)
      scrollTl.fromTo(node, { scale: 1, opacity: 1 }, { scale: 1.2, opacity: 0, ease: 'power2.in' }, 0.70)

    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={sectionRef} className="pinned-section z-30">
      <div className="bg-image absolute inset-0 z-0">
        <img
          src="/focus_dashboard.jpg"
          alt="Focus Dashboard"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="vignette-overlay" />

      <div className="pulsing-node-wrap absolute z-10" style={{ left: '50%', top: '45%', transform: 'translate(-50%, -50%)' }}>
        <div className="pulsing-node" />
      </div>

      <div
        className="headline absolute z-10"
        style={{ left: '6vw', top: '40vh', width: '44vw' }}
      >
        <h2 className="font-heading font-bold text-flow-text" style={{ fontSize: 'clamp(30px, 4vw, 58px)', lineHeight: 1.05 }}>
          See what matters.
        </h2>
        <h2 className="font-heading font-bold text-flow-text" style={{ fontSize: 'clamp(30px, 4vw, 58px)', lineHeight: 1.05 }}>
          Skip the noise.
        </h2>
      </div>

      <div
        className="body-copy absolute z-10"
        style={{ left: '6vw', top: '60vh', width: '30vw' }}
      >
        <p className="text-flow-text-secondary leading-relaxed" style={{ fontSize: 'clamp(14px, 1.2vw, 17px)' }}>
          A single view of what's running, what needs you, and what's next—without opening five tabs.
        </p>
      </div>
    </div>
  )
}
