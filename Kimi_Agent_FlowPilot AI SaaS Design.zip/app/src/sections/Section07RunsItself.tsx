import { useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function Section07RunsItself() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      const bg = section.querySelector('.bg-image')
      const headline = section.querySelector('.headline')
      const body = section.querySelector('.body-copy')
      const cta = section.querySelector('.cta-btn')
      const node = section.querySelector('.pulsing-node-wrap')

      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=140%',
          pin: true,
          scrub: 0.6,
        }
      })

      // ENTRANCE (0-30%)
      scrollTl.fromTo(bg, { scale: 1.06, y: '5vh', opacity: 0.65 }, { scale: 1, y: 0, opacity: 1, ease: 'none' }, 0)
      scrollTl.fromTo(headline, { x: '-14vw', opacity: 0 }, { x: 0, opacity: 1, ease: 'power2.out' }, 0.08)
      scrollTl.fromTo(body, { x: '-8vw', opacity: 0 }, { x: 0, opacity: 1, ease: 'power2.out' }, 0.14)
      scrollTl.fromTo(cta, { y: '4vh', opacity: 0 }, { y: 0, opacity: 1, ease: 'power2.out' }, 0.18)
      scrollTl.fromTo(node, { scale: 0.2, opacity: 0 }, { scale: 1, opacity: 1, ease: 'back.out(1.4)' }, 0)

      // EXIT (70-100%)
      scrollTl.fromTo(bg, { opacity: 1 }, { opacity: 0, ease: 'power2.in' }, 0.70)
      scrollTl.fromTo(headline, { x: 0, opacity: 1 }, { x: '-10vw', opacity: 0, ease: 'power2.in' }, 0.70)
      scrollTl.fromTo(body, { opacity: 1 }, { opacity: 0, ease: 'power2.in' }, 0.72)
      scrollTl.fromTo(cta, { opacity: 1 }, { opacity: 0, ease: 'power2.in' }, 0.74)
      scrollTl.fromTo(node, { scale: 1, opacity: 1 }, { scale: 1.35, opacity: 0, ease: 'power2.in' }, 0.70)

    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={sectionRef} className="pinned-section z-[70]">
      <div className="bg-image absolute inset-0 z-0">
        <img
          src="/status_queue_ui.jpg"
          alt="Status Queue"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="vignette-overlay" />

      <div className="pulsing-node-wrap absolute z-10" style={{ left: '50%', top: '50%', transform: 'translate(-50%, -50%)' }}>
        <div className="pulsing-node" />
      </div>

      <div
        className="headline absolute z-10"
        style={{ left: '6vw', top: '40vh', width: '46vw' }}
      >
        <h2 className="font-heading font-bold text-flow-text" style={{ fontSize: 'clamp(30px, 4vw, 58px)', lineHeight: 1.05 }}>
          It runs itself.
        </h2>
        <h2 className="font-heading font-bold text-flow-text" style={{ fontSize: 'clamp(30px, 4vw, 58px)', lineHeight: 1.05 }}>
          You stay in control.
        </h2>
      </div>

      <div
        className="body-copy absolute z-10"
        style={{ left: '6vw', top: '62vh', width: '32vw' }}
      >
        <p className="text-flow-text-secondary leading-relaxed mb-6" style={{ fontSize: 'clamp(14px, 1.2vw, 17px)' }}>
          Auto-execute the routine. Loop in people for approvals, exceptions, and judgment calls.
        </p>
      </div>

      <div
        className="cta-btn absolute z-10"
        style={{ left: '6vw', top: '76vh' }}
      >
        <button className="btn-secondary">Request a demo</button>
      </div>
    </div>
  )
}
