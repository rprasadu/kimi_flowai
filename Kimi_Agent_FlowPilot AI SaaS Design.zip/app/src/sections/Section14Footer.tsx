import { useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Github, Linkedin, Twitter } from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

const footerLinks = {
  Product: ['Features', 'Pricing', 'Integrations', 'Changelog'],
  Solutions: ['Operations', 'Customer Success', 'HR Teams', 'Finance'],
  Resources: ['Blog', 'Documentation', 'API Docs', 'Community'],
  Company: ['About', 'Careers', 'Contact', 'Press'],
}

export default function Section14Footer() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      const columns = section.querySelectorAll('.footer-column')

      columns.forEach((col, i) => {
        gsap.fromTo(col, { y: '2vh', opacity: 0 }, {
          y: 0, opacity: 1,
          scrollTrigger: { trigger: col, start: `top ${95 - i * 2}%`, end: `top ${80 - i * 2}%`, scrub: true }
        })
      })

    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <footer ref={sectionRef} className="bg-[#070A12] relative z-[90] pt-16 pb-8 border-t border-white/5">
      <div className="max-w-6xl mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-10 mb-16">
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category} className="footer-column">
              <h4 className="font-heading font-semibold text-flow-text text-sm mb-4">{category}</h4>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-flow-text-secondary text-sm hover:text-flow-text transition-colors duration-200"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between pt-8 border-t border-white/5 gap-6">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-flow-red flex items-center justify-center">
              <svg width="10" height="10" viewBox="0 0 14 14" fill="none">
                <path d="M2 7h10M7 2v10" stroke="white" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </div>
            <span className="font-heading font-semibold text-flow-text text-sm">FlowPilot</span>
          </div>

          <div className="flex items-center gap-6 text-xs text-flow-text-secondary">
            <a href="#" className="hover:text-flow-text transition-colors">Privacy</a>
            <a href="#" className="hover:text-flow-text transition-colors">Terms</a>
            <a href="#" className="hover:text-flow-text transition-colors">Cookies</a>
            <span>© 2025 FlowPilot AI, Inc.</span>
          </div>

          <div className="flex items-center gap-4">
            <a href="#" className="text-flow-text-secondary hover:text-flow-text transition-colors">
              <Twitter size={16} />
            </a>
            <a href="#" className="text-flow-text-secondary hover:text-flow-text transition-colors">
              <Linkedin size={16} />
            </a>
            <a href="#" className="text-flow-text-secondary hover:text-flow-text transition-colors">
              <Github size={16} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
