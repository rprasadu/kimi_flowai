import { useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Play } from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

export default function Section01Hero() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const headlineRef = useRef<HTMLDivElement>(null)
  const bodyRef = useRef<HTMLDivElement>(null)
  const nodeRef = useRef<HTMLDivElement>(null)
  const vignetteRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    const headline = headlineRef.current
    const body = bodyRef.current
    const node = nodeRef.current
    const vignette = vignetteRef.current
    if (!section || !headline || !body || !node || !vignette) return

    const ctx = gsap.context(() => {
      // Auto-play entrance on load
      const loadTl = gsap.timeline({ delay: 0.2 })
      loadTl.fromTo(vignette, { opacity: 0 }, { opacity: 1, duration: 0.6, ease: 'power2.out' })
      loadTl.fromTo(headline.children, { y: 26, opacity: 0 }, { y: 0, opacity: 1, duration: 0.7, ease: 'power3.out', stagger: 0.06 }, '-=0.3')
      loadTl.fromTo(body.children, { y: 18, opacity: 0 }, { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out', stagger: 0.08 }, '-=0.3')
      loadTl.fromTo(node, { scale: 0.6, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.45, ease: 'back.out(1.6)' }, '-=0.4')

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset to visible when scrolling back
            gsap.set(headline.children, { x: 0, opacity: 1 })
            gsap.set(body.children, { x: 0, opacity: 1 })
            gsap.set(node, { scale: 1, opacity: 1 })
          }
        }
      })

      // Ambient parallax during settle (0-70%)
      scrollTl.fromTo(section.querySelector('.bg-image'), { y: 0 }, { y: '-2vh', ease: 'none' }, 0)

      // EXIT (70-100%)
      scrollTl.fromTo(headline.children, { x: 0, opacity: 1 }, { x: '-40vw', opacity: 0, ease: 'power2.in', stagger: 0.02 }, 0.70)
      scrollTl.fromTo(body.children, { x: 0, opacity: 1 }, { x: '-20vw', opacity: 0, ease: 'power2.in', stagger: 0.03 }, 0.72)
      scrollTl.fromTo(node, { scale: 1, opacity: 1 }, { scale: 1.6, opacity: 0, ease: 'power2.in' }, 0.70)

    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={sectionRef} className="pinned-section z-10">
      {/* Background Image */}
      <div className="bg-image absolute inset-0 z-0">
        <img
          src="/hero_dashboard_node.jpg"
          alt="FlowPilot Dashboard"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Vignette */}
      <div ref={vignetteRef} className="vignette-overlay opacity-0" />

      {/* Pulsing Node */}
      <div
        ref={nodeRef}
        className="absolute z-10 opacity-0"
        style={{ left: '74vw', top: '56vh', transform: 'translate(-50%, -50%)' }}
      >
        <div className="pulsing-node" />
      </div>

      {/* Content */}
      <div className="absolute z-10" style={{ left: '6vw', top: '14vh', width: '62vw' }}>
        <div ref={headlineRef}>
          <span className="font-mono-label text-flow-text-secondary block mb-4">FLOWPILOT</span>
          <h1 className="font-heading font-bold text-flow-text" style={{ fontSize: 'clamp(36px, 5vw, 72px)', lineHeight: 0.98 }}>
            Workflows that
          </h1>
          <h1 className="font-heading font-bold text-flow-text" style={{ fontSize: 'clamp(36px, 5vw, 72px)', lineHeight: 0.98 }}>
            run themselves
          </h1>
        </div>
      </div>

      <div ref={bodyRef} className="absolute z-10" style={{ left: '6vw', top: '54vh', width: '34vw' }}>
        <p className="text-flow-text-secondary leading-relaxed mb-8" style={{ fontSize: 'clamp(14px, 1.2vw, 17px)' }}>
          FlowPilot watches how your team works, suggests automations, and keeps them running—without losing the human check.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <button className="btn-primary">Start free</button>
          <button className="btn-secondary gap-2">
            <Play size={16} />
            Watch a 90-second demo
          </button>
        </div>
      </div>
    </div>
  )
}
