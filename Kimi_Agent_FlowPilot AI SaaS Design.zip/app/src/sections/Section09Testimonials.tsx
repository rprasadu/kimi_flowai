import { useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Quote } from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

const testimonials = [
  {
    quote: "FlowPilot turned our ops into a system we can actually iterate on.",
    name: "Jordan Lee",
    role: "Head of Ops",
    company: "Northwind",
  },
  {
    quote: "I described a process in two sentences. The first draft was 80% done.",
    name: "Samira O.",
    role: "Product Lead",
    company: "Canopy",
  },
  {
    quote: "We cut daily busywork by half within the first month.",
    name: "Diego R.",
    role: "COO",
    company: "Kitefold",
  },
]

export default function Section09Testimonials() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      const headline = section.querySelector('.headline')
      const cards = section.querySelectorAll('.testimonial-card')

      gsap.fromTo(headline,
        { y: '6vh', opacity: 0 },
        {
          y: 0, opacity: 1,
          scrollTrigger: { trigger: headline, start: 'top 85%', end: 'top 50%', scrub: true }
        }
      )

      cards.forEach((card, i) => {
        gsap.fromTo(card,
          { x: '-6vw', opacity: 0 },
          {
            x: 0, opacity: 1,
            scrollTrigger: { trigger: card, start: `top ${85 - i * 5}%`, end: `top ${55 - i * 5}%`, scrub: true }
          }
        )
        const accent = card.querySelector('.accent-line')
        if (accent) {
          gsap.fromTo(accent, { scaleY: 0 }, {
            scaleY: 1,
            scrollTrigger: { trigger: card, start: 'top 80%', end: 'top 60%', scrub: true }
          })
        }
      })

    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={sectionRef} id="customers" className="flowing-section-light relative z-[90]">
      <div className="max-w-6xl mx-auto px-6 lg:px-10">
        <h2 className="headline font-heading font-bold text-flow-dark mb-16" style={{ fontSize: 'clamp(28px, 3.5vw, 48px)' }}>
          Loved by teams that ship.
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={i}
              className="testimonial-card relative bg-white rounded-2xl p-7 shadow-card-sm border border-gray-100"
            >
              <div className="accent-line absolute left-0 top-7 bottom-7 w-[3px] bg-flow-red rounded-full origin-top" />
              <Quote size={20} className="text-flow-red/40 mb-4" />
              <p className="text-flow-text-dark leading-relaxed mb-6 text-[15px]">
                "{t.quote}"
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center text-sm font-semibold text-gray-600">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-flow-text-dark text-sm">{t.name}</p>
                  <p className="text-flow-text-dark-secondary text-xs">{t.role}, {t.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
