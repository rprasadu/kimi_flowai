import { useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function Section13FinalCTA() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      const content = section.querySelector('.cta-content')
      const buttons = section.querySelectorAll('.cta-btn')

      gsap.fromTo(content, { y: '6vh', opacity: 0 }, {
        y: 0, opacity: 1,
        scrollTrigger: { trigger: content, start: 'top 85%', end: 'top 55%', scrub: true }
      })

      buttons.forEach((btn, i) => {
        gsap.fromTo(btn, { scale: 0.96, opacity: 0 }, {
          scale: 1, opacity: 1,
          scrollTrigger: { trigger: btn, start: `top ${90 - i * 3}%`, end: `top ${70 - i * 3}%`, scrub: true }
        })
      })

    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={sectionRef} className="flowing-section-dark relative z-[90] py-32">
      <div className="cta-content max-w-2xl mx-auto px-6 lg:px-10 text-center">
        <h2 className="font-heading font-bold text-flow-text mb-6" style={{ fontSize: 'clamp(32px, 4vw, 56px)' }}>
          Ready to automate your first workflow?
        </h2>
        <p className="text-flow-text-secondary text-lg mb-10">
          Start free. No credit card. No setup call.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button className="cta-btn btn-primary px-8 py-4 text-base">
            Start free
          </button>
          <button className="cta-btn btn-secondary px-8 py-4 text-base">
            Talk to sales
          </button>
        </div>
      </div>
    </div>
  )
}
