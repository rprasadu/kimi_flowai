import { useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function Section08Security() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      const bg = section.querySelector('.bg-image')
      const headline = section.querySelector('.headline')
      const body = section.querySelector('.body-copy')
      const chips = section.querySelectorAll('.trust-chip')
      const node = section.querySelector('.pulsing-node-wrap')
      const lightBridge = section.querySelector('.light-bridge')

      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=120%',
          pin: true,
          scrub: 0.6,
        }
      })

      // ENTRANCE (0-30%)
      scrollTl.fromTo(bg, { scale: 1.06, opacity: 0.65 }, { scale: 1, opacity: 1, ease: 'none' }, 0)
      scrollTl.fromTo(headline, { y: '-10vh', opacity: 0 }, { y: 0, opacity: 1, ease: 'power2.out' }, 0.06)
      scrollTl.fromTo(body, { y: '6vh', opacity: 0 }, { y: 0, opacity: 1, ease: 'power2.out' }, 0.12)
      scrollTl.fromTo(chips, { y: '4vh', opacity: 0 }, { y: 0, opacity: 1, ease: 'power2.out', stagger: 0.02 }, 0.16)
      scrollTl.fromTo(node, { scale: 0.2, opacity: 0 }, { scale: 1, opacity: 1, ease: 'back.out(1.4)' }, 0)

      // Light bridge fade in at 85% for transition to flowing sections
      scrollTl.fromTo(lightBridge, { opacity: 0 }, { opacity: 1, ease: 'power2.out' }, 0.85)

      // EXIT (70-100%)
      scrollTl.fromTo(bg, { opacity: 1 }, { opacity: 0, ease: 'power2.in' }, 0.70)
      scrollTl.fromTo(headline, { opacity: 1 }, { opacity: 0, ease: 'power2.in' }, 0.70)
      scrollTl.fromTo(body, { opacity: 1 }, { opacity: 0, ease: 'power2.in' }, 0.72)
      scrollTl.fromTo(chips, { opacity: 1 }, { opacity: 0, ease: 'power2.in', stagger: 0.01 }, 0.74)
      scrollTl.fromTo(node, { scale: 1, opacity: 1 }, { scale: 1.25, opacity: 0, ease: 'power2.in' }, 0.70)

    }, section)

    return () => ctx.revert()
  }, [])

  const trustChips = ['SOC 2 Type II', 'GDPR', 'SSO', 'Audit logs']

  return (
    <div ref={sectionRef} className="pinned-section z-[80]">
      <div className="bg-image absolute inset-0 z-0">
        <img
          src="/security_clean_ui.jpg"
          alt="Security Panel"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="vignette-overlay" />

      {/* Light bridge for transition to flowing sections */}
      <div className="light-bridge absolute inset-0 bg-[#F6F7FA] opacity-0 z-[5] pointer-events-none" />

      <div className="pulsing-node-wrap absolute z-10" style={{ left: '50%', top: '55%', transform: 'translate(-50%, -50%)' }}>
        <div className="pulsing-node" />
      </div>

      <div
        className="headline absolute z-10 text-center"
        style={{ left: '50%', top: '20vh', width: '78vw', transform: 'translateX(-50%)' }}
      >
        <h2 className="font-heading font-bold text-flow-text" style={{ fontSize: 'clamp(32px, 4.5vw, 64px)' }}>
          Secure by default.
        </h2>
        <h2 className="font-heading font-bold text-flow-text" style={{ fontSize: 'clamp(32px, 4.5vw, 64px)' }}>
          Built for teams.
        </h2>
      </div>

      <div
        className="body-copy absolute z-10 text-center"
        style={{ left: '50%', top: '46vh', width: '52vw', transform: 'translateX(-50%)' }}
      >
        <p className="text-flow-text-secondary leading-relaxed" style={{ fontSize: 'clamp(14px, 1.2vw, 18px)' }}>
          Encryption in transit and at rest. Granular permissions. Full audit history. Compliance-ready controls for scale.
        </p>
      </div>

      <div
        className="absolute z-10 flex flex-wrap justify-center gap-3"
        style={{ left: '50%', top: '66vh', transform: 'translateX(-50%)' }}
      >
        {trustChips.map((chip) => (
          <span
            key={chip}
            className="trust-chip px-4 py-2 rounded-full text-sm font-medium border border-white/10 text-flow-text-secondary bg-white/5"
          >
            {chip}
          </span>
        ))}
      </div>
    </div>
  )
}
