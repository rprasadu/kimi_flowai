import { useState, useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Check, Sparkles } from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

const plans = [
  {
    name: 'Starter',
    price: 'Free',
    period: '',
    description: 'For individuals exploring automation.',
    features: ['3 active workflows', '50 runs/month', 'Core integrations', 'Email support'],
    highlighted: false,
    cta: 'Start free',
  },
  {
    name: 'Professional',
    price: '$29',
    period: '/member/month',
    description: 'For teams building real workflows.',
    features: ['Unlimited workflows', 'Unlimited runs', 'All integrations', 'Priority support', 'Team collaboration', 'Audit logs'],
    highlighted: true,
    cta: 'Start free',
  },
  {
    name: 'Business',
    price: 'Custom',
    period: '',
    description: 'For orgs that need control, SLAs, and support.',
    features: ['Everything in Pro', 'SSO & SAML', 'Custom contracts', 'Dedicated support', 'SLA guarantee', 'Onboarding'],
    highlighted: false,
    cta: 'Talk to sales',
  },
]

export default function Section10Pricing() {
  const [annual, setAnnual] = useState(true)
  const sectionRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      const header = section.querySelector('.pricing-header')
      const cards = section.querySelectorAll('.pricing-card')

      gsap.fromTo(header, { y: '4vh', opacity: 0 }, {
        y: 0, opacity: 1,
        scrollTrigger: { trigger: header, start: 'top 85%', end: 'top 60%', scrub: true }
      })

      cards.forEach((card, i) => {
        gsap.fromTo(card, { y: '8vh', opacity: 0 }, {
          y: 0, opacity: 1,
          scrollTrigger: { trigger: card, start: `top ${90 - i * 3}%`, end: `top ${65 - i * 3}%`, scrub: true }
        })
      })

    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={sectionRef} id="pricing" className="flowing-section-light relative z-[90]">
      <div className="max-w-6xl mx-auto px-6 lg:px-10">
        <div className="pricing-header flex flex-col lg:flex-row lg:items-end lg:justify-between mb-14">
          <h2 className="font-heading font-bold text-flow-dark mb-6 lg:mb-0" style={{ fontSize: 'clamp(28px, 3.5vw, 48px)' }}>
            Simple pricing.<br />No surprises.
          </h2>

          <div className="flex items-center gap-3 bg-white rounded-full p-1 border border-gray-200 shadow-sm">
            <button
              onClick={() => setAnnual(true)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${annual ? 'bg-flow-dark text-white' : 'text-flow-text-dark-secondary hover:text-flow-text-dark'}`}
            >
              Annual
            </button>
            <button
              onClick={() => setAnnual(false)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${!annual ? 'bg-flow-dark text-white' : 'text-flow-text-dark-secondary hover:text-flow-text-dark'}`}
            >
              Monthly
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {plans.map((plan, i) => (
            <div
              key={i}
              className={`pricing-card relative rounded-2xl p-7 transition-all duration-300 ${
                plan.highlighted
                  ? 'bg-flow-dark text-white shadow-card scale-[1.02] lg:scale-105'
                  : 'bg-white text-flow-text-dark border border-gray-100 shadow-card-sm'
              }`}
            >
              {plan.highlighted && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex items-center gap-1 bg-flow-red text-white text-xs font-semibold px-3 py-1 rounded-full">
                  <Sparkles size={12} />
                  Most popular
                </div>
              )}

              <h3 className={`font-heading font-semibold text-lg mb-2 ${plan.highlighted ? 'text-white' : 'text-flow-text-dark'}`}>
                {plan.name}
              </h3>

              <div className="flex items-baseline gap-1 mb-2">
                <span className="font-heading font-bold text-3xl">
                  {annual ? plan.price : plan.price === '$29' ? '$39' : plan.price}
                </span>
                <span className={`text-sm ${plan.highlighted ? 'text-flow-text-secondary' : 'text-flow-text-dark-secondary'}`}>
                  {plan.period}
                </span>
              </div>

              <p className={`text-sm mb-6 ${plan.highlighted ? 'text-flow-text-secondary' : 'text-flow-text-dark-secondary'}`}>
                {plan.description}
              </p>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, j) => (
                  <li key={j} className="flex items-center gap-3 text-sm">
                    <Check size={16} className={plan.highlighted ? 'text-flow-red' : 'text-green-500'} />
                    <span className={plan.highlighted ? 'text-flow-text' : 'text-flow-text-dark'}>{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                className={`w-full py-3 rounded-xl font-medium text-sm transition-all duration-200 ${
                  plan.highlighted
                    ? 'bg-flow-red text-white hover:bg-red-600'
                    : 'bg-gray-100 text-flow-text-dark hover:bg-gray-200'
                }`}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
