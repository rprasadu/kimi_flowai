import { useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import {
  Wand2,
  GitBranch,
  ShieldCheck,
  Clock,
  Plug,
  ScrollText,
  Users,
  Webhook,
} from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

const features = [
  { icon: Wand2, label: 'AI workflow builder' },
  { icon: GitBranch, label: 'Conditional logic & branches' },
  { icon: ShieldCheck, label: 'Approvals & escalations' },
  { icon: Clock, label: 'Scheduled & event-driven triggers' },
  { icon: Plug, label: 'Integrations library' },
  { icon: ScrollText, label: 'Audit logs & versioning' },
  { icon: Users, label: 'SSO & team permissions' },
  { icon: Webhook, label: 'Custom webhooks' },
]

export default function Section11Features() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      const headline = section.querySelector('.headline')
      const items = section.querySelectorAll('.feature-item')

      gsap.fromTo(headline, { x: '-6vw', opacity: 0 }, {
        x: 0, opacity: 1,
        scrollTrigger: { trigger: headline, start: 'top 85%', end: 'top 55%', scrub: true }
      })

      items.forEach((item, i) => {
        gsap.fromTo(item, { y: '3vh', opacity: 0 }, {
          y: 0, opacity: 1,
          scrollTrigger: { trigger: item, start: `top ${90 - i * 2}%`, end: `top ${70 - i * 2}%`, scrub: true }
        })
        const icon = item.querySelector('.feature-icon')
        if (icon) {
          gsap.fromTo(icon, { scale: 0.8 }, {
            scale: 1,
            scrollTrigger: { trigger: item, start: 'top 85%', end: 'top 65%', scrub: true }
          })
        }
      })

    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={sectionRef} id="product" className="flowing-section-light relative z-[90]">
      <div className="max-w-6xl mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          <div>
            <h2 className="headline font-heading font-bold text-flow-dark" style={{ fontSize: 'clamp(28px, 3.5vw, 48px)' }}>
              Everything you need to automate work.
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {features.map((feature, i) => (
              <div
                key={i}
                className="feature-item flex items-center gap-4 p-4 rounded-xl bg-white border border-gray-100 shadow-sm hover:shadow-md hover:border-flow-red/20 transition-all duration-200 group"
              >
                <div className="feature-icon w-10 h-10 rounded-lg bg-flow-dark/5 flex items-center justify-center group-hover:bg-flow-red/10 transition-colors">
                  <feature.icon size={18} className="text-flow-dark group-hover:text-flow-red transition-colors" />
                </div>
                <span className="text-flow-text-dark text-sm font-medium">{feature.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
