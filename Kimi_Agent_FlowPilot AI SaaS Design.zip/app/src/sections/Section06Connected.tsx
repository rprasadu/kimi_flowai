import { useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function Section06Connected() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      const bg = section.querySelector('.bg-image')
      const headline = section.querySelector('.headline')
      const subheadline = section.querySelector('.subheadline')
      const node = section.querySelector('.pulsing-node-wrap')

      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      })

      // ENTRANCE (0-30%)
      scrollTl.fromTo(bg, { scale: 1.07, y: '6vh', opacity: 0.6 }, { scale: 1, y: 0, opacity: 1, ease: 'none' }, 0)
      scrollTl.fromTo(headline, { y: '-10vh', opacity: 0 }, { y: 0, opacity: 1, ease: 'power2.out' }, 0.06)
      scrollTl.fromTo(subheadline, { y: '6vh', opacity: 0 }, { y: 0, opacity: 1, ease: 'power2.out' }, 0.12)
      scrollTl.fromTo(node, { scale: 0.2, opacity: 0 }, { scale: 1, opacity: 1, ease: 'back.out(1.4)' }, 0)

      // EXIT (70-100%)
      scrollTl.fromTo(bg, { scale: 1, opacity: 1 }, { scale: 1.05, opacity: 0, ease: 'power2.in' }, 0.70)
      scrollTl.fromTo(headline, { y: 0, opacity: 1 }, { y: '-8vh', opacity: 0, ease: 'power2.in' }, 0.70)
      scrollTl.fromTo(subheadline, { opacity: 1 }, { opacity: 0, ease: 'power2.in' }, 0.72)
      scrollTl.fromTo(node, { scale: 1, opacity: 1 }, { scale: 1.25, opacity: 0, ease: 'power2.in' }, 0.70)

    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={sectionRef} className="pinned-section z-[60]">
      <div className="bg-image absolute inset-0 z-0">
        <img
          src="/connected_stack_ui.jpg"
          alt="Connected Stack"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="vignette-overlay" />

      <div className="pulsing-node-wrap absolute z-10" style={{ left: '50%', top: '55%', transform: 'translate(-50%, -50%)' }}>
        <div className="pulsing-node" />
      </div>

      <div
        className="headline absolute z-10 text-center"
        style={{ left: '50%', top: '18vh', width: '72vw', transform: 'translateX(-50%)' }}
      >
        <h2 className="font-heading font-bold text-flow-text" style={{ fontSize: 'clamp(32px, 4.5vw, 64px)' }}>
          Your stack.
        </h2>
        <h2 className="font-heading font-bold text-flow-text" style={{ fontSize: 'clamp(32px, 4.5vw, 64px)' }}>
          One nervous system.
        </h2>
      </div>

      <div
        className="subheadline absolute z-10 text-center"
        style={{ left: '50%', top: '46vh', width: '52vw', transform: 'translateX(-50%)' }}
      >
        <p className="text-flow-text-secondary leading-relaxed" style={{ fontSize: 'clamp(14px, 1.2vw, 18px)' }}>
          Connect the tools your team already uses. FlowPilot routes work across apps—and keeps context intact.
        </p>
      </div>
    </div>
  )
}
