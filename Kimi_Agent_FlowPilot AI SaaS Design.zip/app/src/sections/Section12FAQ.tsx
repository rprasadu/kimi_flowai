import { useState, useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { ChevronDown } from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

const faqs = [
  {
    q: "Do I need to know how to code?",
    a: "Not at all. FlowPilot is built for operations teams, not engineers. Describe what you want in plain English, and the AI builds the workflow. You review and adjust using a visual editor.",
  },
  {
    q: "How does the AI build workflows?",
    a: "You describe a process—like 'when a deal closes in Salesforce, create a project in Asana and notify Slack.' FlowPilot drafts the steps, conditions, and connections. You review, tweak, and activate.",
  },
  {
    q: "What apps do you integrate with?",
    a: "We integrate with 100+ tools including Salesforce, HubSpot, Slack, Notion, Asana, Jira, Google Workspace, Microsoft Teams, and more. We also support custom webhooks for anything else.",
  },
  {
    q: "Is there a free plan?",
    a: "Yes. The Starter plan is free forever and includes 3 active workflows and 50 runs per month. It's perfect for exploring what FlowPilot can do before upgrading.",
  },
  {
    q: "Can I invite external collaborators?",
    a: "Yes. You can invite guests and external stakeholders to specific workflows with limited permissions. They can approve, comment, and view without needing a full seat.",
  },
  {
    q: "How do you keep data secure?",
    a: "We use encryption in transit (TLS 1.3) and at rest (AES-256). We're SOC 2 Type II certified and GDPR compliant. You own your data, and you can delete it anytime.",
  },
]

export default function Section12FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)
  const sectionRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      const headline = section.querySelector('.headline')
      const items = section.querySelectorAll('.faq-item')

      gsap.fromTo(headline, { y: '3vh', opacity: 0 }, {
        y: 0, opacity: 1,
        scrollTrigger: { trigger: headline, start: 'top 85%', end: 'top 65%', scrub: true }
      })

      items.forEach((item, i) => {
        gsap.fromTo(item, { y: '3vh', opacity: 0 }, {
          y: 0, opacity: 1,
          scrollTrigger: { trigger: item, start: `top ${90 - i * 2}%`, end: `top ${75 - i * 2}%`, scrub: true }
        })
      })

    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={sectionRef} className="flowing-section-light relative z-[90]">
      <div className="max-w-3xl mx-auto px-6 lg:px-10">
        <h2 className="headline font-heading font-bold text-flow-dark text-center mb-14" style={{ fontSize: 'clamp(28px, 3.5vw, 48px)' }}>
          Questions? Answers.
        </h2>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="faq-item bg-white rounded-xl border border-gray-100 overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-5 text-left hover:bg-gray-50/50 transition-colors"
              >
                <span className="font-medium text-flow-text-dark text-[15px] pr-4">{faq.q}</span>
                <ChevronDown
                  size={18}
                  className={`text-flow-text-dark-secondary flex-shrink-0 transition-transform duration-200 ${openIndex === i ? 'rotate-180' : ''}`}
                />
              </button>
              <div
                className="overflow-hidden transition-all duration-200"
                style={{
                  maxHeight: openIndex === i ? '200px' : '0',
                  opacity: openIndex === i ? 1 : 0,
                }}
              >
                <p className="px-5 pb-5 text-flow-text-dark-secondary text-sm leading-relaxed">
                  {faq.a}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
