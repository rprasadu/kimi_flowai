import { useRef, useLayoutEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function Section04AIBuilder() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useLayoutEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const ctx = gsap.context(() => {
      const bg = section.querySelector('.bg-image')
      const headline = section.querySelector('.headline')
      const body = section.querySelector('.body-copy')
      const node = section.querySelector('.pulsing-node-wrap')

      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=140%',
          pin: true,
          scrub: 0.6,
        }
      })

      // ENTRANCE (0-30%)
      scrollTl.fromTo(bg, { x: '6vw', opacity: 0.6 }, { x: 0, opacity: 1, ease: 'none' }, 0)
      scrollTl.fromTo(headline, { x: '18vw', opacity: 0 }, { x: 0, opacity: 1, ease: 'power2.out' }, 0.06)
      scrollTl.fromTo(body, { x: '10vw', opacity: 0 }, { x: 0, opacity: 1, ease: 'power2.out' }, 0.12)
      scrollTl.fromTo(node, { scale: 0.25, opacity: 0 }, { scale: 1, opacity: 1, ease: 'back.out(1.4)' }, 0)

      // EXIT (70-100%)
      scrollTl.fromTo(bg, { x: 0, opacity: 1 }, { x: '-4vw', opacity: 0, ease: 'power2.in' }, 0.70)
      scrollTl.fromTo(headline, { y: 0, opacity: 1 }, { y: '-8vh', opacity: 0, ease: 'power2.in' }, 0.70)
      scrollTl.fromTo(body, { opacity: 1 }, { opacity: 0, ease: 'power2.in' }, 0.72)
      scrollTl.fromTo(node, { scale: 1, opacity: 1 }, { scale: 1.35, opacity: 0, ease: 'power2.in' }, 0.70)

    }, section)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={sectionRef} className="pinned-section z-40">
      <div className="bg-image absolute inset-0 z-0">
        <img
          src="/workflow_builder_node.jpg"
          alt="AI Workflow Builder"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="vignette-overlay" />

      <div className="pulsing-node-wrap absolute z-10" style={{ left: '50%', top: '52%', transform: 'translate(-50%, -50%)' }}>
        <div className="pulsing-node" />
      </div>

      <div
        className="headline absolute z-10"
        style={{ left: '52vw', top: '32vh', width: '42vw' }}
      >
        <h2 className="font-heading font-bold text-flow-text" style={{ fontSize: 'clamp(30px, 4vw, 58px)', lineHeight: 1.05 }}>
          Describe it.
        </h2>
        <h2 className="font-heading font-bold text-flow-text" style={{ fontSize: 'clamp(30px, 4vw, 58px)', lineHeight: 1.05 }}>
          FlowPilot builds it.
        </h2>
      </div>

      <div
        className="body-copy absolute z-10"
        style={{ left: '52vw', top: '56vh', width: '34vw' }}
      >
        <p className="text-flow-text-secondary leading-relaxed" style={{ fontSize: 'clamp(14px, 1.2vw, 17px)' }}>
          Type what you want—like a brief. The AI drafts steps, conditions, and handoffs. You review, adjust, and ship.
        </p>
      </div>
    </div>
  )
}
