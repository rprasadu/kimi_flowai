import { useEffect } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

import Navbar from './components/Navbar'
import Section01Hero from './sections/Section01Hero'
import Section02Unread from './sections/Section02Unread'
import Section03Focus from './sections/Section03Focus'
import Section04AIBuilder from './sections/Section04AIBuilder'
import Section05Split from './sections/Section05Split'
import Section06Connected from './sections/Section06Connected'
import Section07RunsItself from './sections/Section07RunsItself'
import Section08Security from './sections/Section08Security'
import Section09Testimonials from './sections/Section09Testimonials'
import Section10Pricing from './sections/Section10Pricing'
import Section11Features from './sections/Section11Features'
import Section12FAQ from './sections/Section12FAQ'
import Section13FinalCTA from './sections/Section13FinalCTA'
import Section14Footer from './sections/Section14Footer'

gsap.registerPlugin(ScrollTrigger)

function App() {
  useEffect(() => {
    // Wait for all ScrollTriggers to be created
    const timer = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter(st => st.vars.pin)
        .sort((a, b) => a.start - b.start)

      const maxScroll = ScrollTrigger.maxScroll(window)
      if (!maxScroll || pinned.length === 0) return

      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }))

      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            const inPinned = pinnedRanges.some(r => value >= r.start - 0.02 && value <= r.end + 0.02)
            if (!inPinned) return value

            const target = pinnedRanges.reduce((closest, r) =>
              Math.abs(r.center - value) < Math.abs(closest - value) ? r.center : closest,
              pinnedRanges[0]?.center ?? 0
            )
            return target
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        }
      })
    }, 500)

    return () => {
      clearTimeout(timer)
      ScrollTrigger.getAll().forEach(st => st.kill())
    }
  }, [])

  return (
    <div className="relative">
      <Navbar />

      {/* Pinned cinematic sections */}
      <Section01Hero />
      <Section02Unread />
      <Section03Focus />
      <Section04AIBuilder />
      <Section05Split />
      <Section06Connected />
      <Section07RunsItself />
      <Section08Security />

      {/* Flowing content sections */}
      <Section09Testimonials />
      <Section10Pricing />
      <Section11Features />
      <Section12FAQ />
      <Section13FinalCTA />
      <Section14Footer />

      {/* Noise overlay */}
      <div className="noise-overlay" />
    </div>
  )
}

export default App
